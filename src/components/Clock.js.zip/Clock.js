import React, { Component } from 'react';
import './Clock.css';

class Clock extends Component {

    constructor(props) {
        super(props);
        this.state = {
            day: new Date().getDay(),
            hour: new Date().getHours(),
            minute: new Date().getMinutes(),
            second: new Date().getSeconds(),
            // currentDay: this.renderSwitch()
        };
    }

    componentDidMount() {
        this.intervalID = setInterval(
            () => this.tick(),
            1000
        );
    }

    componentWillUnmount() {
        clearInterval(this.intervalID);
    }

    tick() {
        this.setState({
            day: new Date().getDay(),
            hour: new Date().getHours(),
            minute: new Date().getMinutes(),
            second: new Date().getSeconds(),
            // currentDay: this.renderSwitch()
        });
    }

    renderSwitch(day) {
        switch(day) {
            case '0':
                return (
                    document.getElementById("sun").className += "active"
                )
            case '1':
                return (
                    document.getElementById("mon").className += "active"
                )
            case '2':
                return (
                    document.getElementById("tue").className += "active"
                )
            case '3':
                return (
                    document.getElementById("wed").className += "active"
                )
            case '4':
                return (
                    document.getElementById("thu").className += "active"
                )
            case '5':
                return (
                    document.getElementById("fri").className += "active"
                )
            case '6':
                return (
                    document.getElementById("sat").className += "active"
                )
            default:
                return null;
        }
    }

    render() {        
        return (
            <div className="clock">

                {this.renderSwitch(this.state.day)}

                <div className="clock-screen">
                    <ul className="days">
                        <li id="mon">Mon</li>
                        <li id="tue">Tue</li>
                        <li id="wed">Wed</li>
                        <li id="thu">Thu</li>
                        <li id="fri">Fri</li>
                        <li id="sat">Sat</li>
                        <li id="sun">Sun</li>
                    </ul>

                    <ul className="time">
                        <li>{this.state.hour}</li>:
                        <li>{this.state.minute}</li>{/*:*/}
                        {/* <li>{this.state.second}</li> */}
                    </ul>

                    {/* Day {this.state.day} <br /> */}
                </div>
            </div>
        )
    }
}

export default Clock;